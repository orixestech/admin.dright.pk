</div>

<footer class="content-footer">
    <div>© 2024 D-Right - <a href="https://dright.net/" target="_blank">D-Right Technologies</a></div>
</footer>
</div>
</div>
</div>
<script src="<?= $template ?>vendors/datepicker/daterangepicker.js"></script>
<script src="<?= $template ?>assets/js/app.min.js"></script>
</body>
</html>


