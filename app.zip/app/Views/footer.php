</div>

<footer class="content-footer">
    <div>© 2020 Baston - <a href="http://laborasyon.com" target="_blank">Laborasyon</a></div>
    <div>
        <nav class="nav">
            <a href="https://themeforest.net/licenses/standard" class="nav-link">Licenses</a>
            <a href="#" class="nav-link">Change Log</a>
            <a href="#" class="nav-link">Get Help</a>
        </nav>
    </div>
</footer>
</div>
</div>
</div>


<script src="<?= $template ?>vendors/datepicker/daterangepicker.js"></script>


<script src="<?= $template ?>assets/js/app.min.js"></script>
</body>
</html>


