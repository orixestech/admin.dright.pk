<div class="modal fade bd-example-modal-horizontal-form" id="DescriptionModel">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Description Detail</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true" class="fa fa-close"></span>
                </button>
            </div>
            <form method="post" action="" name="desform" id="desform" class="needs-validation" novalidate=""
                  enctype="multipart/form-data">
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12"><div id="showDescription"></div></div>
                </div>
            </div>
            </form>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
